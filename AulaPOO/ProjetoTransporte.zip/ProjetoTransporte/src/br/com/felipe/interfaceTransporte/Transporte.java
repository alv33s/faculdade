package br.com.felipe.interfaceTransporte;

public interface Transporte {

	public void mover();
	
}
